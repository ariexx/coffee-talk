<?php return array (
  'confirmation' => 'App\\Http\\Livewire\\Confirmation',
  'order-detail' => 'App\\Http\\Livewire\\OrderDetail',
  'order-page' => 'App\\Http\\Livewire\\OrderPage',
);