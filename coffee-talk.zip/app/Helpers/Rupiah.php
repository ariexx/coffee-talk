<?php

if(!function_exists('rupiah')) {
    function rupiah($angka){
        return "Rp " . number_format($angka,2,',','.');
    }
}
