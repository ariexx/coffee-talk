<?php

namespace App\Filament\Resources\OrderResource\Widgets;

use App\Models\Order;
use Filament\Widgets\Widget;

class OrderOverview extends Widget
{
    protected static string $view = 'filament.resources.order-resource.widgets.order-overview';

}
